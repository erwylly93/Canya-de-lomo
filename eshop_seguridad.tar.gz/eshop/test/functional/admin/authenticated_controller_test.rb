require 'test_helper'

class Admin::AuthenticatedControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
