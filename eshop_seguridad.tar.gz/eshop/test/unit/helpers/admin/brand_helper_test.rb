require 'test_helper'

class Admin::BrandHelperTest < ActionView::TestCase
end
