require 'test_helper'

class Admin::OrderHelperTest < ActionView::TestCase
end
