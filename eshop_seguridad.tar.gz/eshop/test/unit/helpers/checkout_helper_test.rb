require 'test_helper'

class CheckoutHelperTest < ActionView::TestCase
end
