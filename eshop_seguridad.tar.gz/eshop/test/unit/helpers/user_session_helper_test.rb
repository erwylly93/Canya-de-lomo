require 'test_helper'

class UserSessionHelperTest < ActionView::TestCase
end
