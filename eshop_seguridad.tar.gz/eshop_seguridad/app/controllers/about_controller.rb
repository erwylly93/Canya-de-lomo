# encoding = utf-8
class AboutController < ApplicationController
  def index
  	@page_title = 'Sobre Caña de Lomo'
  end
end
