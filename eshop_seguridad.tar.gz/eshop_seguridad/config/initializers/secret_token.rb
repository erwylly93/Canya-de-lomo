# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Eshop::Application.config.secret_token = 'bdc2162947c5220a61be472ce04a60bab944797744ccde97c79cb52b56bf0372f25df305a1097833ef4e8238abe013106b9ed81a26dab55836c5110f3620584c'
