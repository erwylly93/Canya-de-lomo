require 'test_helper'

class Admin::SupplierHelperTest < ActionView::TestCase
end
